<?php
/* ASISTENT 30 – voľné termíny z rezervačného systému Barbershopu 30 (www.barbershop30.sk/rezervacia).
 *
 * Číta to isté, čo vidí návštevník v rezervačnom formulári: pravidlá kalendára (rozsah dní, zatvorené dni,
 * sviatky) a voľné začiatky pre zvolenú službu a barbera. Nikdy neodosiela objednávku (makeOrder sa tu
 * nepoužíva) a z odpovede berie len časy v tvare HH:MM; mená ani poznámky iných zákazníkov sa sem nedostanú.
 * Zapína ho config.php ('kalendar' => ['url' => …]) až so súhlasom prevádzky; bez neho vráti stav nepripojene.
 *
 * Výsledok pre model aj okno na webe:
 *   stav: overene | ziadny_volny | zatvorene | mimo_rozsahu | minulost | neznamy_barber | neznama_sluzba |
 *         nepripojene | chyba
 *   overene_o (HH:MM, čas Bratislava), barber, datum (YYYY-MM-DD), sluzba, trvanie_min, casy [HH:MM, …]
 * Objednávkové okno na webe (barbershop-30/assets/objednavka.js) berie cez api.php aj mená barberov pre službu
 * (objednavka_barberi) a rozsah a zatvorené dni kalendára (objednavka_dni). */
declare(strict_types=1);
if (!defined('ASISTENT')) { http_response_code(403); exit; }

use Symfony\Component\HttpClient\HttpClient;

const TZ = 'Europe/Bratislava';
const KAL_TTL = 120;            // voľné časy staršie ako 2 minúty sa nepoužijú (iný zákazník si medzitým mohol termín vziať)
const KAL_TTL_PRAVIDLA = 3600;  // barberi a pravidlá kalendára sa menia zriedka
const KAL_TIMEOUT = 6.0;        // sekúnd na celé overenie; potom poctivo „neviem overiť“

/* služby zo zoznamu rezervačného systému (id, názov, trvanie v minútach) – rovnaké ako cenník na webe */
const SLUZBY = [
  1 => ['Pánsky strih', 40], 18 => ['Pánsky strih a úprava brady', 60], 19 => ['Pánsky strih, dĺžka vlasov nad 10 cm', 60],
  5 => ['Strih pre malých gentlemanov', 45], 2 => ['Oholenie hlavy', 25], 3 => ['Úprava brady', 20],
  4 => ['Holenie do hladka Hot Towel', 30], 11 => ['Farbenie brady', 30], 14 => ['Balíček 1', 65],
  15 => ['Ultra inclusive Barbershop30', 80], 6 => ['Starostlivosť o pleť PREMIUM', 30], 7 => ['Úprava obočia', 5],
  8 => ['Depilácia uší a nosa voskom', 10], 10 => ['Kreatívny ornament na hlave', 10], 12 => ['Farbenie obočia', 10],
];

function kal_konfig(): ?array {
  $k = konfig()['kalendar'] ?? null;
  return is_array($k) && !empty($k['url']) ? $k : null;
}

function teraz(): DateTimeImmutable { return new DateTimeImmutable('now', new DateTimeZone(TZ)); }

/* bez diakritiky a malými písmenami (Adrián = adrian) */
function bez_diakritiky(string $s): string {
  $t = strtr(mb_strtolower(trim($s)), ['á' => 'a', 'ä' => 'a', 'č' => 'c', 'ď' => 'd', 'é' => 'e', 'í' => 'i', 'ĺ' => 'l', 'ľ' => 'l',
    'ň' => 'n', 'ó' => 'o', 'ô' => 'o', 'ŕ' => 'r', 'š' => 's', 'ť' => 't', 'ú' => 'u', 'ý' => 'y', 'ž' => 'z']);
  return preg_replace('/[^a-z0-9 ]/', '', $t) ?? '';
}

/* ---------- vyrovnávacia pamäť na disku (data/), nikdy nie s osobnými údajmi: len časy a pravidlá ---------- */
function kal_cache(string $kluc, int $ttl, callable $ziskaj): array {
  $dir = (string) (konfig()['cache_dir'] ?? __DIR__ . '/../data');
  $f = $dir . '/kal-' . hash('sha256', $kluc) . '.json';
  $c = is_file($f) ? json_decode((string) file_get_contents($f), true) : null;
  if (is_array($c) && isset($c['t'], $c['v']) && time() - (int) $c['t'] < $ttl) return [$c['v'], (int) $c['t']];
  $v = $ziskaj();
  @file_put_contents($f, json_encode(['t' => time(), 'v' => $v]), LOCK_EX);
  if (mt_rand(1, 50) === 1) foreach (glob($dir . '/kal-*.json') ?: [] as $g) if (time() - (int) @filemtime($g) > 86400) @unlink($g);   // upratanie starých dní
  return [$v, time()];
}

/* ---------- rozhranie rezervačného formulára (POST JSON s CSRF tokenom stránky, ako prehliadač) ---------- */
final class Rezervacie {
  private $http; private string $url; private ?string $token = null; private array $cookies = [];
  public function __construct(string $url, float $timeout) {
    $this->url = rtrim($url, '/');
    $this->http = HttpClient::create(['timeout' => $timeout, 'max_duration' => $timeout, 'headers' => ['User-Agent' => 'Barbershop30-asistent/1.0']]);
  }
  /* token formulára a cookie stránky rezervácie sa držia 5 minút (cache_dir): každé čítanie by inak bolo dve
     požiadavky na rezervačný systém (GET stránky + POST) */
  private function subor(): string { return (string) (konfig()['cache_dir'] ?? __DIR__ . '/../data') . '/kal-relacia-' . hash('sha256', $this->url) . '.json'; }
  private function prihlas(): bool {
    if ($this->token !== null) return false;
    $c = is_file($this->subor()) ? json_decode((string) @file_get_contents($this->subor()), true) : null;
    if (is_array($c) && is_string($c['token'] ?? null) && is_array($c['cookies'] ?? null) && time() - (int) ($c['t'] ?? 0) < 300) {
      $this->token = $c['token']; $this->cookies = $c['cookies']; return true;
    }
    $r = $this->http->request('GET', $this->url);
    $html = $r->getContent();
    if (!preg_match('/name="csrf-token" content="([^"]+)"/', $html, $m)) throw new RuntimeException('chýba CSRF token');
    $this->token = $m[1];
    foreach ($r->getHeaders()['set-cookie'] ?? [] as $c) { $kv = explode(';', $c, 2)[0]; [$n, $v] = array_pad(explode('=', $kv, 2), 2, ''); $this->cookies[$n] = $v; }
    @file_put_contents($this->subor(), json_encode(['t' => time(), 'token' => $this->token, 'cookies' => $this->cookies]), LOCK_EX);
    @chmod($this->subor(), 0600);
    return false;
  }
  public function volaj(string $metoda, array $data): array {
    if ($metoda === 'makeOrder') throw new LogicException('objednávku asistent nikdy neodosiela');
    $zPamate = $this->prihlas();
    try { return $this->posli($metoda, $data); }
    catch (Throwable $e) {
      if (!$zPamate) throw $e;
      // uložený token už rezervačný systém neberie (vypršal): raz nanovo so stránkou
      @unlink($this->subor()); $this->token = null; $this->cookies = [];
      $this->prihlas();
      return $this->posli($metoda, $data);
    }
  }
  private function posli(string $metoda, array $data): array {
    $cookie = implode('; ', array_map(fn ($n, $v) => "$n=$v", array_keys($this->cookies), $this->cookies));
    $r = $this->http->request('POST', $this->url . '/ajax', [
      'headers' => ['X-CSRF-TOKEN' => $this->token, 'X-Requested-With' => 'XMLHttpRequest', 'Accept' => 'application/json', 'Cookie' => $cookie],
      'json' => ['ajax' => true, 'ajax_method' => $metoda] + $data,
    ]);
    $j = $r->toArray();
    if (!isset($j['result']) || !is_array($j['result'])) throw new RuntimeException('neočakávaná odpoveď');
    return $j['result'];
  }
}

/* dátum z rezervačného systému (1.1.2026 aj 01.01.2026) na YYYY-MM-DD */
function kal_datum(string $d): ?string {
  if (!preg_match('/^(\d{1,2})\.(\d{1,2})\.(\d{4})$/', trim($d), $m)) return null;
  return sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
}

/* spojenie s rezervačným systémom: $volaj z testu, inak z config.php; bez napojenia null */
function kal_spojenie(?callable $volaj): ?callable {
  if ($volaj) return $volaj;
  $k = kal_konfig();
  if (!$k) return null;
  $api = new Rezervacie((string) $k['url'], (float) ($k['timeout'] ?? KAL_TIMEOUT));
  return fn (string $m, array $d) => $api->volaj($m, $d);
}

/* barberi, ktorí robia službu (id 0 = „Nezáleží“ vo formulári); z každého len id, meno a rozvrh (pole
   opening_hours a time_multiple), ktoré rezervačný systém potrebuje späť, nikdy e‑mail ani telefón */
function kal_barberi(int $sluzba, callable $volaj): array {
  return kal_cache("barberi2:$sluzba", KAL_TTL_PRAVIDLA, function () use ($volaj, $sluzba) {
    $r = $volaj('getEmployees', ['services' => [$sluzba]]);
    $out = [];
    foreach ((array) ($r['employees'] ?? []) as $e) if (isset($e['id'], $e['name'])) $out[] = ['id' => (int) $e['id'], 'meno' => (string) $e['name'],
      'rozvrh' => ['opening_hours' => $e['opening_hours'] ?? null, 'time_multiple' => $e['time_multiple'] ?? null]];
    return $out;
  })[0];
}

/* barber tak, ako ho posiela formulár systému (overené na www.barbershop30.sk/rezervacia 2026‑10‑25): objekt,
   nie číslo. Číslo 0 systém odmietne („Nie je vybratá služba alebo pracovník“) a iné číslo ticho ignoruje
   (vráti kalendár a časy u kohokoľvek, teda aj časy, keď vybraný barber nemá voľno). Objekt bez opening_hours
   skončí chybou 500, preto ide s rozvrhom, ale bez kontaktov. */
function kal_objekt(array $kto): array {
  if ($kto['id'] === 0) return ['name' => $kto['system'] ?? 'Nezáleží', 'id' => 0];
  return ['id' => $kto['id'], 'name' => $kto['meno']] + ($kto['rozvrh'] ?? ['opening_hours' => null, 'time_multiple' => null]);
}

/* barber podľa mena (bez diakritiky); „ktokoľvek“ = 0 */
function kal_najdi(string $barber, array $barberi): ?array {
  $hladaj = bez_diakritiky($barber);
  if (in_array($hladaj, ['', 'ktokolvek', 'nezalezi', 'hocikto', 'akykolvek'], true)) {
    foreach ($barberi as $b) if ($b['id'] === 0) return ['id' => 0, 'meno' => 'ktokoľvek', 'system' => $b['meno']];
    return ['id' => 0, 'meno' => 'ktokoľvek'];
  }
  foreach ($barberi as $b) if ($b['id'] !== 0 && bez_diakritiky($b['meno']) === $hladaj) return $b;
  return null;
}
function kal_mena(array $barberi): array { return array_values(array_filter(array_map(fn ($b) => $b['id'] ? $b['meno'] : null, $barberi))); }

/* pravidlá kalendára: rozsah dní, zatvorené dni v týždni, sviatky */
function kal_pravidla(int $sluzba, array $kto, callable $volaj): array {
  return kal_cache("kalendar:$sluzba:{$kto['id']}", KAL_TTL_PRAVIDLA, function () use ($volaj, $sluzba, $kto) {
    $c = (array) (($volaj('getCalendar', ['services' => [$sluzba], 'employee' => kal_objekt($kto)]))['calendar'] ?? []);
    return ['od' => kal_datum((string) ($c['limits']['min'] ?? '')), 'do' => kal_datum((string) ($c['limits']['max'] ?? '')),
      'dni' => array_values(array_map('strval', (array) ($c['disabled_days'] ?? []))),
      'sviatky' => array_values(array_filter(array_map(fn ($d) => kal_datum((string) $d), (array) ($c['disabled_dates'] ?? []))))];
  })[0];
}

/* Objednávka na webe, krok barber: mená tých, ktorí službu robia (bez id a ďalších údajov). */
function objednavka_barberi(int $sluzba, ?callable $volaj = null): array {
  if (!isset(SLUZBY[$sluzba])) return ['stav' => 'neznama_sluzba'];
  $volaj = kal_spojenie($volaj);
  if (!$volaj) return ['stav' => 'nepripojene'];
  try { return ['stav' => 'ok', 'barberi' => kal_mena(kal_barberi($sluzba, $volaj))]; }
  catch (Throwable $e) { error_log('objednavka barberi: ' . $e->getMessage()); return ['stav' => 'chyba']; }
}

/* Objednávka na webe, krok deň: rozsah rezervácie, zatvorené dni v týždni (Po … Ne), sviatky a voľno barbera.
   Sviatky sú len dni, keď je zatvorené pre celý tím (aj pri „Nezáleží“); ostatné zakázané dni barbera sú jeho voľno
   (nález REZ-03: okno ich ukazovalo ako „zatvorené“). Pravidlá „Nezáleží“ sú v tej istej cache (1 h). */
function objednavka_dni(string $barber, int $sluzba, ?callable $volaj = null): array {
  if (!isset(SLUZBY[$sluzba])) return ['stav' => 'neznama_sluzba'];
  $volaj = kal_spojenie($volaj);
  if (!$volaj) return ['stav' => 'nepripojene'];
  try {
    $kto = kal_najdi($barber, kal_barberi($sluzba, $volaj));
    if (!$kto) return ['stav' => 'neznamy_barber'];
    $p = kal_pravidla($sluzba, $kto, $volaj);
    if (!$p['od'] || !$p['do']) return ['stav' => 'chyba'];
    $dnes = teraz()->format('Y-m-d');
    $sviatky = $p['sviatky']; $volno = [];
    if ($kto['id'] !== 0) {
      $spolocne = kal_pravidla($sluzba, kal_najdi('nezalezi', kal_barberi($sluzba, $volaj)), $volaj)['sviatky'];
      $volno = array_values(array_diff($sviatky, $spolocne));
      $sviatky = array_values(array_intersect($sviatky, $spolocne));
    }
    return ['stav' => 'ok', 'barber' => $kto['meno'], 'dnes' => $dnes, 'od' => max($p['od'], $dnes), 'do' => $p['do'], 'zatvorene' => $p['dni'], 'sviatky' => $sviatky, 'volno' => $volno];
  } catch (Throwable $e) { error_log('objednavka dni: ' . $e->getMessage()); return ['stav' => 'chyba']; }
}

/* Overí voľné začiatky. $volaj(metoda, data) je rozhranie systému (v testoch falošné). */
function volne_terminy(string $barber, string $datum, int $sluzba, ?callable $volaj = null): array {
  $teraz = teraz();
  $zaklad = ['overene_o' => $teraz->format('H:i'), 'datum' => $datum];
  if (!isset(SLUZBY[$sluzba])) return $zaklad + ['stav' => 'neznama_sluzba'];
  [$nazov, $trvanie] = SLUZBY[$sluzba];
  $zaklad += ['sluzba' => $nazov, 'trvanie_min' => $trvanie];
  $den = DateTimeImmutable::createFromFormat('!Y-m-d', $datum, new DateTimeZone(TZ));
  if (!$den || $den->format('Y-m-d') !== $datum) return $zaklad + ['stav' => 'chyba', 'dovod' => 'neplatný dátum'];
  if ($den < $teraz->setTime(0, 0)) return $zaklad + ['stav' => 'minulost'];
  $volaj = kal_spojenie($volaj);
  if (!$volaj) return $zaklad + ['stav' => 'nepripojene'];
  try {
    $barberi = kal_barberi($sluzba, $volaj);
    $kto = kal_najdi($barber, $barberi);
    if (!$kto) return $zaklad + ['stav' => 'neznamy_barber', 'barber' => $barber, 'barberi' => kal_mena($barberi)];
    $zaklad['barber'] = $kto['meno'];

    $pravidla = kal_pravidla($sluzba, $kto, $volaj);
    if (!$pravidla['od'] || !$pravidla['do']) return $zaklad + ['stav' => 'chyba', 'dovod' => 'kalendár bez rozsahu'];
    if ($datum < $pravidla['od'] || $datum > $pravidla['do']) return $zaklad + ['stav' => 'mimo_rozsahu', 'od' => $pravidla['od'], 'do' => $pravidla['do']];
    $skratka = ['Po', 'Ut', 'St', 'Št', 'Pi', 'So', 'Ne'][(int) $den->format('N') - 1];
    if (in_array($skratka, $pravidla['dni'], true)) return $zaklad + ['stav' => 'zatvorene', 'dovod' => 'zatvorený deň v týždni'];
    if (in_array($datum, $pravidla['sviatky'], true)) return $zaklad + ['stav' => 'zatvorene', 'dovod' => 'sviatok'];

    // voľné začiatky: z odpovede len reťazce HH:MM, nič iné
    [$casy, $kedy] = kal_cache("casy:$sluzba:{$kto['id']}:$datum", KAL_TTL, function () use ($volaj, $sluzba, $kto, $den) {
      // dátum ako objekt kalendára formulára (selectedDate); samotný reťazec systém nevie spracovať (chyba 500)
      $r = $volaj('getTime', ['services' => [$sluzba], 'employee' => kal_objekt($kto), 'date' => ['selectedDate' => $den->format('d.m.Y')]]);
      if (!array_key_exists('times', $r)) throw new RuntimeException('odpoveď bez časov');
      $out = [];
      if (is_array($r['times'])) array_walk_recursive($r['times'], function ($v) use (&$out) { if (is_string($v) && preg_match('/^([01]?\d|2[0-3]):[0-5]\d$/', trim($v))) $out[] = sprintf('%05s', trim($v)); });
      return $out;
    });
    if (time() - $kedy > KAL_TTL) return $zaklad + ['stav' => 'chyba', 'dovod' => 'zastarané údaje'];
    $casy = array_values(array_unique($casy)); sort($casy);
    // dnes len časy, ktoré ešte neprešli
    if ($datum === $teraz->format('Y-m-d')) $casy = array_values(array_filter($casy, fn ($c) => $c > $teraz->format('H:i')));
    $zaklad['overene_o'] = (new DateTimeImmutable('@' . $kedy))->setTimezone(new DateTimeZone(TZ))->format('H:i');
    return $zaklad + ($casy ? ['stav' => 'overene', 'casy' => $casy] : ['stav' => 'ziadny_volny']);
  } catch (Throwable $e) {
    error_log('asistent kalendar: ' . $e->getMessage());
    return $zaklad + ['stav' => 'chyba', 'dovod' => 'spojenie s rezervačným systémom zlyhalo'];
  }
}
